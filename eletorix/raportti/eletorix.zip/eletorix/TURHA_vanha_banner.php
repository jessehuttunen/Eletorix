    <header>
            <a href="index.php"><div id="logot">
            <img src="kuvat/logo.svg" alt="Eletorix logo" id="logo"/>
            <img src="kuvat/otsikko.svg" alt="Eletorix otsikko" id="otsikko"/>
                </div></a>
        <form action="hae.php" method="post">
            <div  id="hakudiv">
                <input type="text[]" name="tuotteennimi" id="haku">
                <button type="submit" id="hae_nappi">
                <img src="kuvat/haku.svg" alt="Hae" id="hakukuva"/>
                </button>
            </div>
        </form>
        <div class="bannerTabs">
            <?php
            if (!isset($_SESSION)) session_start();
                if (isset($_SESSION['suosikit']) && sizeof($_SESSION['suosikit'])>0) {
                    $suosikit = $_SESSION['suosikit'];
                    $suosikitLkm = "<span class='suosikitLkm'> " . sizeof($suosikit) . "</span>";
                } else { $suosikitLkm = ""; };
            ?>
            <a href="lisaa.php"><button class="add">Jätä ilmoitus</button></a>
            <a href="suosikit.php"><button class="add">Suosikit<?php echo $suosikitLkm; ?></button></a>
           <?php 
            if (isset($_SESSION['username'])) 
                echo "<a href='account.php'><button class='add'>".$_SESSION['username']."</button></a>"; 
            else 
                echo "";
            ?>
            <button class='add'>Login</button>
            
        </div>
    </header>
