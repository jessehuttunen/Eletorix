<?php
    session_start();
        $hakusana = "";   
        $kategoria = "Kaikki";
        $kategorianimi = $kategoria;
        if (isset($_POST["tuotteennimi"]) && !empty($_POST["tuotteennimi"])){
		$hakusana = $_POST["tuotteennimi"];  
        };
        if (isset($_POST["kategoria"]) && !empty($_POST["kategoria"])){
        $kategoria = $_POST["kategoria"];    
            $kategorianimi = $kategoria;
            
            if ($kategorianimi != "Kaikki"){
                require_once("db-init.php");
                $kat = $db->prepare("SELECT * FROM kategoria WHERE idkategoria=:kategoria;");
                $kat->bindValue(':kategoria', $kategoria, PDO::PARAM_INT);
                $kat->execute(); 
                while($row = $kat->fetch(PDO::FETCH_ASSOC)) {
                $kategorianimi = $row['kategorianimi'];
                }
            }
        
        };
        
    ?>
<html>
    <head>
    <title>Eletorix - Kaiken elektroniikan kauppapaikka</title>
    <link rel="icon" href="kuvat/logo.png" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display" rel="stylesheet">
    <link rel="stylesheet" href="hae.css"> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
</head>
<body>
    <form action="hae.php" method="post">
    <header>
        <a href="index.php"><div id="logot">
        <img src="kuvat/logo.svg" alt="Eletorix logo" id="logo"/>
        <img src="kuvat/otsikko.svg" alt="Eletorix otsikko" id="otsikko"/>
            </div></a>
        <div  id="hakudiv">
            <input type="text[]" name="tuotteennimi" id="haku">
            <button type="submit" id="hae_nappi">
            <img src="kuvat/haku.svg" alt="Hae" id="hakukuva"/>
            </button>
        </div>
        <div>
             <?php
		if (isset($_SESSION['userId'])) {
		      echo	'<a href="lisaa.php"><button class="add" type=button>Jätä ilmoitus</button></a>
              <a href="rekkirj/includes/logout.inc.php"><button class="add" type=button>kirjaudu ulos</button></a>';
        }
        else {
            echo '<a href="rekkirj/index.php"><button class="add" type=button>Kirjaudu sisään</button></a>';
        }
	?>
             </div>
    </header>
        <div id="tuloksia"> <strong><p id="maara"></p></strong><p>Hakutulosta sanalle:  <strong><?php echo $hakusana;?></strong> | Kategoriassa:  <strong><?php echo $kategorianimi;?></strong></p></div>
	<div id="jako">        
        <div id="kategoria">
            <button id="nayta" type="button">Rajaa hakua</button>
            <div id="kategoria_title">Rajaukset</div>
            <div id="nakyy">
                <div id="kategoria_div">
                <select name="kategoria" id="kategoria">
                    <option value="Kaikki">Kategoria</option>
                    <?php
                        require_once("db-init.php");
                        $sql = $db->query('SELECT * FROM kategoria;');
                        while($row = $sql->fetch(PDO::FETCH_ASSOC)) {
                            $idkategoria = $row['idkategoria'];
                            $kategorianimi = $row['kategorianimi'];
                            echo "<option value=".$idkategoria.">".$kategorianimi."</option>";
                        }
                    ?>
                </select>
                </div>
                <div class="kaupunki_div">
                <input type="text[]" name="kaupunki" class="kaupunki" placeholder="Kaupunki">
                </div>
                <div class="kaupunki_div">
                <input type="text[]" name="m_hinta" class="kaupunki" placeholder="Max hinta">
                </div>
                <div class="kaupunki_div">
                <input type="text[]" name="p_hinta" class="kaupunki" placeholder="Min hinta">
                </div>
                <button type="submit" id="rajaa">Rajaa</button>
            </div>
            
        </div>
        
        </form>
        <div id="ilmoitukset">    
        


<?php
require_once("db-init.php");  
            
$tuotteennimi = NULL;   
$kategoria = "Kaikki";
$kaupunki = NULL;
$m_hinta = NULL;
$p_hinta = NULL;
            
if (isset($_POST["tuotteennimi"]) && !empty($_POST["tuotteennimi"])){
    $tuotteennimi = $_POST["tuotteennimi"];  
};
if (isset($_POST["kategoria"]) && !empty($_POST["kategoria"])){
    $kategoria = $_POST["kategoria"];
};
if (isset($_POST["kaupunki"]) && !empty($_POST["kaupunki"])){
    $kaupunki = $_POST["kaupunki"];  
};
if (isset($_POST["m_hinta"]) && !empty($_POST["m_hinta"])){
    $m_hinta = $_POST["m_hinta"];  
};   
if (isset($_POST["p_hinta"]) && !empty($_POST["p_hinta"])){
    $p_hinta = $_POST["p_hinta"];  
}; 

if($kategoria=="Kaikki"){
    $kategoria=NULL;
}  

            
$stmt = $db->prepare("SELECT * FROM ilmoitus INNER JOIN kategoria ON ilmoitus.kategoria_idkategoria=kategoria.idkategoria INNER JOIN kayttaja ON ilmoitus.kayttaja_idkayttaja=kayttaja.idkayttaja WHERE tuotteennimi= CASE WHEN :tuotteennimi IS NULL THEN tuotteennimi ELSE :tuotteennimi2 END AND idkategoria= CASE WHEN :kategoria IS NULL THEN idkategoria ELSE :kategoria2 END AND kaupunki= CASE WHEN :kaupunki IS NULL THEN kaupunki ELSE :kaupunki2 END AND hinta <= CASE WHEN :m_hinta IS NULL THEN hinta ELSE :m_hinta2 END AND hinta >= CASE WHEN :p_hinta IS NULL THEN hinta ELSE :p_hinta2 END order by ilmoitus.idilmoitukset desc;");
$stmt->bindValue(':tuotteennimi', $tuotteennimi);
$stmt->bindValue(':tuotteennimi2', $tuotteennimi);
$stmt->bindValue(':kategoria', $kategoria);
$stmt->bindValue(':kategoria2', $kategoria);
$stmt->bindValue(':kaupunki', $kaupunki);
$stmt->bindValue(':kaupunki2', $kaupunki);
$stmt->bindValue(':m_hinta', $m_hinta);
$stmt->bindValue(':m_hinta2', $m_hinta);
$stmt->bindValue(':p_hinta', $p_hinta);
$stmt->bindValue(':p_hinta2', $p_hinta);
$stmt->execute();   

  
while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $id = $row['idilmoitukset'];
    $tuotteennimi = $row['tuotteennimi'];
    $paivays = $row['paivays'];
    $hinta = $row['hinta'];
    $tuotekuvaus = $row['tuotekuvaus'];
    $kuva = $row['kuva'];
    $kategorianimi = $row['kategorianimi'];
    $nimi = $row['nimi'];
    $email = $row['email'];
    $puhnum = $row['puhnum'];
    $osoite = $row['osoite'];
    $kaupunki = $row['kaupunki'];
    echo "
        <div class='ilmoitus'>
        <form action='ilmoitus.php' method='post' >
        <input type='hidden' name='id' value=" . $id . " />
        
        
        <button class='tyyliton'>
        
        <div class='ilmoitus_banner'>
        
        <form action='suosikki.php' method='post'>
        <input type='hidden' name='pois' value=" . $id . " />
        <input value='Poista' type='image' src='kuvat/sydan.png' class='rasti'>
        </form> 
        
        
        
        <form action='mod.php' method='post'>
        <input type='hidden' name='id' value=" . $id . " />
        <input type='hidden' name='paivays' value=" . $paivays . " />
        <input type='hidden' name='tuotteennimi' value=" . $tuotteennimi . " />
        <input type='hidden' name='hinta' value=" . $hinta . " />
        <input type='hidden' name='tuotekuvaus' value=" . $tuotekuvaus . " />
        <input type='hidden' name='kuva' value=" . $kuva . " />
        <input type='hidden' name='kategorianimi' value=" . $kategorianimi . " />
        <input value='Muokkaa' type='image' src='kuvat/cog.png' class='muokkaa'>
        </form>
        
        <form action='remove.php' method='post'>
        <input type='hidden' name='pois' value=" . $id . " />
        <input value='Poista' type='image' src='kuvat/roskis.png' class='rasti'>
        </form> 
        </div>
        

        <img class='tuotekuva' src='kuvat/{$kuva}' alt='Ilmoituksen kuva'>
        <p class='otsikko'>{$tuotteennimi}</p>
        <p class='tuotehinta'>{$hinta}€</p>
        <p class='otsikko'>{$kategorianimi}</p>
        <p class='otsikko'>{$kaupunki}</p>
        </button type='submit'>
        
        </form> </div>";
}
?>
            </div>
	</div>
        
    <?php
    require_once("footer.html"); 
    ?>
    <script src="javas.js"></script>
</body>
</html>